function goToContact() {
  window.location.href = "contact.html";
}
