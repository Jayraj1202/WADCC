function displayOffers() {
  const offers = `
    ☀️ 20% off on residential solar panels installation!<br>
    🔋 Free battery check-up with every system purchase!<br>
    🛠️ First-year maintenance service absolutely free!
  `;
  document.getElementById("offerDisplay").innerHTML = offers;
}
