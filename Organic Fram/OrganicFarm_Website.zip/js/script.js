function showOffers() {
  const offerText = `
    🌿 10% off on all green vegetables!<br>
    🍎 Buy 2kg fruits, get 1kg free!<br>
    🧺 Visit the farm and get a free organic basket!
  `;
  document.getElementById("offerDisplay").innerHTML = offerText;
}
